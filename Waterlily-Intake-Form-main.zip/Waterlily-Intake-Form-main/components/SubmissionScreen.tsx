
import React from 'react';
import { Card } from './ui/Card';
import { Button } from './ui/Button';

interface SubmissionScreenProps {
  onViewSubmission: () => void;
}

const CheckCircleIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);


export const SubmissionScreen: React.FC<SubmissionScreenProps> = ({ onViewSubmission }) => {
  return (
    <Card className="w-full max-w-md text-center animate-fade-in">
      <div className="flex justify-center mb-4">
        <CheckCircleIcon className="w-16 h-16 text-green-500" />
      </div>
      <h2 className="text-3xl font-bold text-gray-800">Submission Complete!</h2>
      <p className="mt-3 text-gray-600">
        Thank you for providing your information. Our team will use this to help predict your long-term care needs.
      </p>
      <div className="mt-8">
        <Button onClick={onViewSubmission}>
          View My Submission
        </Button>
      </div>
    </Card>
  );
};
