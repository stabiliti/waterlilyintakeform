
import React from 'react';
import { Question, Answers } from '../types';
import { SURVEY_QUESTIONS } from '../constants';
import { Card } from './ui/Card';
import { Button } from './ui/Button';

interface ReviewScreenProps {
  answers: Answers;
  onEdit: () => void;
  onSubmit: () => void;
  readOnly?: boolean;
}

export const ReviewScreen: React.FC<ReviewScreenProps> = ({ answers, onEdit, onSubmit, readOnly = false }) => {
  return (
    <Card className="w-full max-w-2xl animate-fade-in">
      <h2 className="text-3xl font-bold text-gray-800 text-center">
        {readOnly ? 'Your Submission' : 'Review Your Answers'}
      </h2>
      <p className="mt-2 text-gray-600 text-center">
        {readOnly ? 'Here is the information you provided.' : 'Please review your answers before submitting.'}
      </p>
      <div className="mt-8 space-y-6">
        {SURVEY_QUESTIONS.map((question: Question) => (
          <div key={question.id} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <p className="font-semibold text-gray-700">{question.title}</p>
            <p className="text-blue-600 mt-1">{answers[question.id] || 'Not answered'}</p>
          </div>
        ))}
      </div>
      {!readOnly && (
        <div className="mt-8 flex justify-between items-center">
          <Button type="button" variant="secondary" onClick={onEdit}>
            Edit
          </Button>
          <Button type="button" variant="primary" onClick={onSubmit}>
            Submit Information
          </Button>
        </div>
      )}
    </Card>
  );
};
