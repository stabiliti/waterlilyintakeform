import React, { useEffect, useRef } from 'react';
import { UserProfile } from '../types';
import { Card } from './ui/Card';

// IMPORTANT: Replace this with your actual Google Cloud Client ID.
// You can create one here: https://console.cloud.google.com/apis/credentials
const GOOGLE_CLIENT_ID = '289233017520-2ho5i8l9ot21d66b4oqn9hv7r7jdhg3d.apps.googleusercontent.com';

interface LoginScreenProps {
  onLoginSuccess: (user: UserProfile) => void;
}

const WaterlilyLogo: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <path d="M50 10 C 25 10, 10 30, 10 50 C 10 70, 25 90, 50 90 M50 10 C 75 10, 90 30, 90 50 C 90 70, 75 90, 50 90" fill="none" stroke="#4a90e2" strokeWidth="5"/>
      <path d="M30 50 C 30 35, 40 25, 50 25 C 60 25, 70 35, 70 50 C 70 65, 60 75, 50 75 C 40 75, 30 65, 30 50" fill="#a8d0f1"/>
      <circle cx="50" cy="50" r="5" fill="#4a90e2"/>
    </svg>
);
  

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
    const signInButton = useRef<HTMLDivElement>(null);

    const handleCredentialResponse = (response: any) => {
        // Decode the JWT token to get user profile information
        try {
            const base64Url = response.credential.split('.')[1];
            const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
            const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
            }).join(''));
        
            const decodedToken = JSON.parse(jsonPayload);
        
            const userProfile: UserProfile = {
              id: decodedToken.sub,
              email: decodedToken.email,
              name: decodedToken.name,
              picture: decodedToken.picture,
            };
            onLoginSuccess(userProfile);
        } catch (error) {
            console.error("Error decoding token:", error);
        }
    };

    useEffect(() => {
        // The google object might not be available immediately
        const checkGoogle = setInterval(() => {
            if (window.google && signInButton.current) {
                clearInterval(checkGoogle);
                window.google.accounts.id.initialize({
                  client_id: GOOGLE_CLIENT_ID,
                  callback: handleCredentialResponse,
                });
                window.google.accounts.id.renderButton(
                  signInButton.current,
                  { theme: 'outline', size: 'large', type: 'standard', text: 'signin_with' } 
                );
                // Optional: Show the One Tap prompt
                // window.google.accounts.id.prompt();
            }
        }, 100);

        return () => clearInterval(checkGoogle);
    }, [onLoginSuccess]);


    return (
        <Card className="w-full max-w-md text-center animate-fade-in">
            <WaterlilyLogo className="w-24 h-24 mx-auto mb-4 text-blue-500" />
            <h1 className="text-3xl font-bold text-gray-800">Welcome to Waterlily</h1>
            <p className="mt-3 text-gray-600">
                Please sign in with your Google account to continue to the intake form.
            </p>
            <div className="mt-8 flex justify-center">
                <div ref={signInButton}></div>
            </div>
        </Card>
    );
};
