
import React, { useState } from 'react';
import { Question, Answers } from '../types';
import { SURVEY_QUESTIONS } from '../constants';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
import { ProgressBar } from './ProgressBar';
import { QuestionCard } from './QuestionCard';

interface SurveyProps {
  onComplete: (answers: Answers) => void;
}

export const Survey: React.FC<SurveyProps> = ({ onComplete }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Answers>({});

  const handleAnswerChange = (questionId: string, value: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  };

  const handleNext = () => {
    if (currentQuestionIndex < SURVEY_QUESTIONS.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      onComplete(answers);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const currentQuestion: Question = SURVEY_QUESTIONS[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === SURVEY_QUESTIONS.length - 1;
  const isNextDisabled = currentQuestion.required && !answers[currentQuestion.id];

  return (
    <Card className="w-full max-w-2xl animate-fade-in">
      <ProgressBar current={currentQuestionIndex + 1} total={SURVEY_QUESTIONS.length} />
      <form onSubmit={(e) => { e.preventDefault(); handleNext(); }}>
        <QuestionCard
          question={currentQuestion}
          value={answers[currentQuestion.id] || ''}
          onAnswer={(value) => handleAnswerChange(currentQuestion.id, value)}
        />
        <div className="mt-8 flex justify-between items-center">
          <Button
            type="button"
            variant="secondary"
            onClick={handlePrevious}
            disabled={currentQuestionIndex === 0}
          >
            Previous
          </Button>
          <p className="text-sm text-gray-500">
            {currentQuestionIndex + 1} / {SURVEY_QUESTIONS.length}
          </p>
          <Button type="submit" variant="primary" disabled={isNextDisabled}>
            {isLastQuestion ? 'Review Answers' : 'Next'}
          </Button>
        </div>
      </form>
    </Card>
  );
};
