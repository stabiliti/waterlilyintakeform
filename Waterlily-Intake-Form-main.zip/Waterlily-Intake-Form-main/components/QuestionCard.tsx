
import React from 'react';
import { Question, InputType } from '../types';

interface QuestionCardProps {
  question: Question;
  value: string;
  onAnswer: (value: string) => void;
}

const inputStyles = "w-full mt-2 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow";

export const QuestionCard: React.FC<QuestionCardProps> = ({ question, value, onAnswer }) => {
  const renderInput = () => {
    switch (question.inputType) {
      case InputType.SELECT:
        return (
          <select
            value={value}
            onChange={(e) => onAnswer(e.target.value)}
            className={`${inputStyles} bg-white`}
            required={question.required}
          >
            <option value="" disabled>Select an option</option>
            {question.options?.map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        );
      case InputType.NUMBER:
      case InputType.DATE:
      case InputType.TEXT:
      default:
        return (
          <input
            type={question.inputType}
            value={value}
            onChange={(e) => onAnswer(e.target.value)}
            placeholder={question.placeholder}
            className={inputStyles}
            required={question.required}
          />
        );
    }
  };

  return (
    <div className="animate-slide-in-left">
      <h2 className="text-2xl font-bold text-gray-800">{question.title}</h2>
      <p className="mt-2 text-gray-600">{question.description}</p>
      <div className="mt-6">
        {renderInput()}
      </div>
    </div>
  );
};
